import { isTelegramLinkPage, telegramPageRequest } from "./features/identity/telegram-linking/telegram-linking-privacy.ts";
import { isTelegramProbePage, telegramProbeEnabled } from "./features/identity/telegram-identity-probe/telegram-identity-probe-config.ts";
import { resolveOwnerSettingsPreflight, ownerSettingsResponseStatus, type OwnerSettingsPreflight } from "./features/community/owner-settings/owner-settings-preflight";
import { getRequestEvent, httpHeader, httpStatus, renderToStream } from "@solidjs/web";
import type { Component } from "solid-js";
import manifest from "virtual:solid-manifest";
import App from "./App";
import Document from "./Document";
import {
  communityPageResponsePolicy,
  resolveCommunityPagePreflight,
  type CommunityPagePreflight,
} from "./features/communities/community-page/community-page-preflight.ts";
import {
  publicProfileResponsePolicy,
  resolvePublicProfilePreflight,
  type PublicProfilePreflight,
} from "./features/profiles/public-profile-page/public-profile-preflight.ts";
import {
  personaPublicProfileResponsePolicy,
  resolvePersonaPublicProfilePreflight,
  type PersonaPublicProfilePreflight,
} from "./features/profiles/persona-public-profile/persona-public-profile-preflight.ts";
import {
  publicPostResponsePolicy,
  resolvePublicPostPreflight,
  type PublicPostPreflight,
} from "./features/posts/public-post/public-post-preflight.ts";
import { bindCommunityCreationAvatarAuthoringRequest } from "./features/community/community-creation-avatar-authoring.ts";
import {
  handleStorefrontResponsePolicy,
  resolveHandleStorefrontPreflight,
  type HandleStorefrontPreflight,
} from "./features/communities/handle-storefront/handle-storefront-preflight.ts";

export interface EntryServerRenderDependencies {
  readonly Application?: Component;
}

export async function render(
  request: Request,
  context?: {
    readonly clientEntry?: string;
    readonly API_NEXT_ORIGIN?: string;
    readonly PUBLIC_APP_CANONICAL_ORIGIN?: string;
    readonly COMMUNITY_CREATION_AVATAR_AUTHORING_ENABLED?: string;
    readonly PERSONA_PUBLIC_PROFILE_PREFLIGHT?: PersonaPublicProfilePreflight;
    readonly CANONICAL_ASSET_ORIGIN?: string;
    readonly DISABLE_HYDRATION?: boolean;
    readonly PUBLIC_POST_PREFLIGHT?: PublicPostPreflight;
  },
  dependencies: EntryServerRenderDependencies = {},
) {
  const event = getRequestEvent();
  if (isTelegramProbePage(new URL(request.url).pathname) &&
      (!telegramProbeEnabled(new URL(request.url).origin, context?.PUBLIC_APP_CANONICAL_ORIGIN) ||
       context?.CANONICAL_ASSET_ORIGIN !== undefined || context?.DISABLE_HYDRATION === true)) {
    return new Response(null, { status: 404, headers: {
      "cache-control": "private, no-store", "referrer-policy": "no-referrer", "x-robots-tag": "noindex, nofollow",
    } });
  }
  if (isTelegramLinkPage(new URL(request.url).pathname)) {
    request = telegramPageRequest(request);
    // The router reads the request event, not this function's argument.
    // Scrub both before preflights, routing or hydration serialization starts.
    if (event !== undefined) event.request = request;
  }
  if (event !== undefined) {
    // SAFETY: entry-server owns this presentation-only hydration flag.
    const locals = event.locals as typeof event.locals & { profileActivityHydrationDisabled?: boolean };
    locals.profileActivityHydrationDisabled = context?.DISABLE_HYDRATION === true;
  }
  const nonce = event?.locals.cspNonce;
  const Application = dependencies.Application ?? App;
  if (event !== undefined) {
    bindCommunityCreationAvatarAuthoringRequest(
      event,
      context?.COMMUNITY_CREATION_AVATAR_AUTHORING_ENABLED,
      context?.PUBLIC_APP_CANONICAL_ORIGIN,
    );
    // SAFETY: this request-local value comes directly from the typed Worker
    // render context and is read only as that same optional string.
    const locals = event.locals as typeof event.locals & {
      apiNextOrigin?: string;
    };
    locals.apiNextOrigin = context?.API_NEXT_ORIGIN;
  }
  // SAFETY: Vite's runtime manifest includes the `_base` member used by the
  // Solid asset resolver even though AssetManifest's public index signature
  // omits it. Every chunk record is preserved; only that resolver base changes.
  const renderManifest = (context?.CANONICAL_ASSET_ORIGIN === undefined
    ? manifest
    : { ...manifest, _base: `${new URL(context.CANONICAL_ASSET_ORIGIN).origin}/` }) as typeof manifest;
  const postPreflight = context?.PUBLIC_POST_PREFLIGHT ??
    await resolvePublicPostPreflight(
      request,
      context?.API_NEXT_ORIGIN,
      context?.PUBLIC_APP_CANONICAL_ORIGIN,
    );
  if (postPreflight !== undefined) {
    if (postPreflight.state.kind === "redirect") {
      return new Response(null, {
        status: 308,
        headers: {
          "Cache-Control": "private, no-store",
          Location: postPreflight.state.location,
          Vary: "Accept-Language, Cookie",
        },
      });
    }
    if (event !== undefined) {
      // SAFETY: this request-local key is written and read only as the
      // PublicPostPreflight produced immediately above.
      const locals = event.locals as typeof event.locals & { publicPostPreflight?: PublicPostPreflight };
      locals.publicPostPreflight = postPreflight;
    }
    const policy = publicPostResponsePolicy(postPreflight.state);
    httpStatus(policy.status, policy.statusText);
    policy.headers.forEach((value, name) => httpHeader(name, value));
  }
  const personaPreflight = context?.PERSONA_PUBLIC_PROFILE_PREFLIGHT ??
    await resolvePersonaPublicProfilePreflight(request, context?.API_NEXT_ORIGIN);
  if (personaPreflight !== undefined) {
    if (event !== undefined) {
      // SAFETY: this request-local key is written and read only as the
      // PersonaPublicProfilePreflight produced immediately above.
      const locals = event.locals as typeof event.locals & {
        personaPublicProfilePreflight?: PersonaPublicProfilePreflight;
      };
      locals.personaPublicProfilePreflight = personaPreflight;
    }
    const policy = personaPublicProfileResponsePolicy(personaPreflight.state);
    httpStatus(policy.status, policy.statusText);
    policy.headers.forEach((value, name) => httpHeader(name, value));
  }
  const ownerSettingsPreflight = await resolveOwnerSettingsPreflight(request, context?.API_NEXT_ORIGIN);
  if (ownerSettingsPreflight !== undefined) {
    if (event !== undefined) {
      // SAFETY: this request-local key is written only with the preflight result above.
      const locals = event.locals as typeof event.locals & { ownerSettingsPreflight?: OwnerSettingsPreflight };
      locals.ownerSettingsPreflight = ownerSettingsPreflight;
    }
    httpStatus(ownerSettingsResponseStatus(ownerSettingsPreflight.state));
    httpHeader("Cache-Control", "private, no-store");
    httpHeader("Vary", "Cookie");
  }
  const communityPreflight = await resolveCommunityPagePreflight(request, context?.API_NEXT_ORIGIN);
  if (communityPreflight !== undefined) {
    if (event !== undefined) {
      // SAFETY: this request-local key is written and read only as the
      // CommunityPagePreflight produced immediately above.
      const locals = event.locals as typeof event.locals & { communityPagePreflight?: CommunityPagePreflight };
      locals.communityPagePreflight = communityPreflight;
    }
    const policy = communityPageResponsePolicy(communityPreflight.state);
    httpStatus(policy.status, policy.statusText);
    policy.headers.forEach((value, name) => httpHeader(name, value));
  }
  const storefrontPreflight = await resolveHandleStorefrontPreflight(request, context?.API_NEXT_ORIGIN);
  if (storefrontPreflight !== undefined) {
    if (event !== undefined) {
      // SAFETY: entry-server alone writes this typed request-local result.
      const locals = event.locals as typeof event.locals & { handleStorefrontPreflight?: HandleStorefrontPreflight };
      locals.handleStorefrontPreflight = storefrontPreflight;
    }
    const policy = handleStorefrontResponsePolicy(storefrontPreflight.state);
    httpStatus(policy.status, policy.statusText);
    policy.headers.forEach((value, name) => httpHeader(name, value));
  }
  const preflight = await resolvePublicProfilePreflight(request, context?.API_NEXT_ORIGIN);
  if (preflight !== undefined) {
    if (event !== undefined) {
      // SAFETY: this request-scoped key is written and read only as the
      // PublicProfilePreflight produced immediately above.
      const locals = event.locals as typeof event.locals & { publicProfilePreflight?: PublicProfilePreflight };
      locals.publicProfilePreflight = preflight;
    }
    const policy = publicProfileResponsePolicy(request, preflight.state);
    if (policy.status === 302) {
      return new Response(null, {
        status: policy.status,
        statusText: policy.statusText,
        headers: policy.headers,
      });
    }
    httpStatus(policy.status, policy.statusText);
    policy.headers.forEach((value, name) => httpHeader(name, value));
  }
  return renderToStream(
    () => (
      <Document
        clientEntry={context?.clientEntry}
        canonicalAssetOrigin={context?.CANONICAL_ASSET_ORIGIN}
        communityCreationAvatarAuthoring={
          context?.COMMUNITY_CREATION_AVATAR_AUTHORING_ENABLED === "true"
        }
        publicAppCanonicalOrigin={context?.PUBLIC_APP_CANONICAL_ORIGIN}
        hydrate={context?.DISABLE_HYDRATION !== true}
      >
        <Application />
      </Document>
    ),
    { nonce, manifest: renderManifest },
  );
}
